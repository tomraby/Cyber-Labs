# Wazuh Lab Setup

Instructions on how to build and configure Wazuh with Sysmon.